// 2. Ambiente Inicial

class MyTerrain extends Plane {

    constructor(scene, nrDivs, texture = scene.materialDefault, textureWidthReps = 1.0, textureHeightReps = 1.0) {
        super(scene, nrDivs);
        
        this.texture = texture;
        this.texWidthReps = textureWidthReps;
        this.texHeightReps = textureHeightReps;

        this.correctTextures();
    }

    correctTextures() {
        var tCoord = 0.0;
        var sCoord = 0.0;
        var patchT = this.patchLength * this.texHeightReps;
        var patchS = this.patchLength * this.texWidthReps;

        for (var j = 0; j <= this.nrDivs; j++) {
            sCoord = 0.0;

            for (var i = 0; i <= this.nrDivs; i++) {
                this.texCoords[2 * (j * (this.nrDivs + 1) + i)] = sCoord;
                this.texCoords[2 * (j * (this.nrDivs + 1) + i) + 1] = tCoord;

                sCoord += patchS;
            }

            tCoord += patchT;
        }
        this.primitiveType = this.scene.gl.TRIANGLE_STRIP;
        this.initGLBuffers();
    };

    display() {
      this.texture.apply();
      super.display();  
    };

}